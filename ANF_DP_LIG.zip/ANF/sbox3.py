# Example 4-bit S-box
sbox = [0x5, 0x3, 0x6, 0x1, 0x0, 0x7, 0x2, 0x4]

# Define boolean functions for each output bit
def output_bit_0(x):
    return (sbox[x] & 0x1) >> 0

def output_bit_1(x):
    return (sbox[x] & 0x2) >> 1

def output_bit_2(x):
    return (sbox[x] & 0x4) >> 2


# Generate truth tables for each boolean function
truth_table_0 = [x for x in range(8) if output_bit_0(x) == 1]
truth_table_1 = [x for x in range(8) if output_bit_1(x) == 1]
truth_table_2 = [x for x in range(8) if output_bit_2(x) == 1]


# Print truth tables
print("Truth Table for Output Bit 0:", truth_table_0)
print("Truth Table for Output Bit 1:", truth_table_1)
print("Truth Table for Output Bit 2:", truth_table_2)


