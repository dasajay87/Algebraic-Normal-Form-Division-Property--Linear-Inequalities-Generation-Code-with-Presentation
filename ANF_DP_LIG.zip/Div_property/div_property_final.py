import random
class Sbox:
    def __init__(self, sbox):
        self.sbox = sbox
        self.SBOXSIZE = self.SboxSize()

    def SboxSize(self):
        """    
        This function is used to calculate the size of a given sbox
        """
        s = format(len(self.sbox), "b")
        num_of_1_in_the_binary_expression_of_the_len_of_sbox = s.count("1")
        assert num_of_1_in_the_binary_expression_of_the_len_of_sbox == 1
        return (len(s) - 1)

    def BitProduct(self, u, x):
        """
        Return the value of the bitproduct function Pi_u(x)
        """
        if (u & x) == u:
            return 1
        else:
            return 0
    
    def HammingWeight(self, k):
        my_list = []  # Initialize an empty list to store results
        for i in range(len(self.sbox)):
            a = self.sbox[i]
            temp = a
            c = 0
            for j in range(self.SBOXSIZE):
                if (temp & 1) == 1:
                    c += 1
                temp = temp >> 1  # Update a by shifting its bits to the right
            if c <= (int(k) - 1):
                my_list.append(a)  # Append c to my_list
        return my_list


        
    def DivProperty_Set(self, list, subset):
        """
        Retrieve DivProperty with a Hamming weight of 2
        """
        flag = 0
        for i in range(len(list)):
            c = 0  # Reset count of 1's for each element in list
            x = 0
            for j in range(len(subset)):
                x = x ^ self.BitProduct(list[i], subset[j])
                c += self.BitProduct(list[i], subset[j])
            print("Number of 1's for u = " + str(list[i]) + " is " + str(c))
            if x == 0:
                flag = 1
            else:
                flag = 0
                break

        return flag

        


        



if __name__ == "__main__":

    #Sbox declare for cipher
    sbox = [0xc, 0x5, 0x6, 0xb, 0x9, 0x0, 0xa, 0xd, 0x3, 0xe, 0xf, 0x8, 0x4, 0x7, 0x1, 0x2]
    sb = Sbox(sbox)
    
    # Print size of SBOX in bits
    print("size of Sbox :", sb.SBOXSIZE)  # Accessing SBOXSIZE attribute, so need to use () for calling the method


    

    k = input('Hamming Weight Pass :')
    print("\n")
    if int(k) > sb.SBOXSIZE:
        print("Sorry !!! \n Hamming Weight more than size of Sbox does not allow \n")
        exit()
    print("\n")
    print("-----------------------------SET WITH HAMMING DISNTANCE = " + k +"------------------------------------------\n")
    list = sb.HammingWeight(k)
    print(list)
    print(':'*100 + "\n")
    #print("\nChoose subset X from sbox Randomly :\n")
    #t = input("\nEnter Size of subset : ")

    #example taken from Yosuki Todo Paper
    print("Subset X :")
    X = [0x0, 0x3, 0x3, 0x3, 0x5, 0x6, 0x8, 0xb, 0xd, 0xe]
    print(X)
   
    flag = sb.DivProperty_Set(list, X)
    #print("\nValues of u for which elements satisying (XOR)Pi_u(x) = 0 are :", div_set)
    if int(flag) == 1:
        print("\nThe Set X satisfying Division Property !")
    else:
        print("\nSet X does not satisfies division property !!")
