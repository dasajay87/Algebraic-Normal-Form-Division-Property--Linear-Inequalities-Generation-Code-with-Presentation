class YourClass:
    def calculateDifferentialDistributionTable(self, cipher):
        self.DDT = [[0]*len(cipher.sbox) for i in range(len(cipher.sbox))]

        for i in range(len(self.DDT)):
            for j in range(len(self.DDT)):
                self.DDT[i ^ j][cipher.sbox[i] ^ cipher.sbox[j]] += 1

    @staticmethod
    def join(i,j):
        return YourClass.integer_to_binary_string(i) + ',' + YourClass.integer_to_binary_string(j)

    def TakeNonZeroEntry(self): 
        non_zero_values = []
        for i, row in enumerate(self.DDT):
            for j, value in enumerate(row):
                if value != 0:
                    non_zero_values.append('(' + YourClass.join(i,j) + ')')
        return non_zero_values

    
    @staticmethod
    def integer_to_binary_string(integer):
        binary_string = bin(integer)[2:]  # Convert integer to binary, remove '0b' prefix
        # Pad or truncate to ensure 3 bits
        if len(binary_string) < 3:
            # Pad with leading zeros
            padded_binary = '0' * (3 - len(binary_string)) + binary_string
        else:
            # Truncate to 3 bits
            padded_binary = binary_string[-3:]

        binary_list = ','.join(padded_binary)  # Insert commas between digits
        return binary_list



class YourCipher:
    def __init__(self):
        # Replace this with your actual S-box initialization logic
        self.sbox = [2, 1, 3, 7, 4, 0, 6, 5]

    

def main():
    # Create an instance of YourCipher
    cipher_instance = YourCipher()

    # Create an instance of the class that contains the method
    obj = YourClass()

    # Call the method with the cipher instance
    obj.calculateDifferentialDistributionTable(cipher_instance)

    # Access the resulting differential distribution table
    print(obj.DDT)
    non_zero_values=obj.TakeNonZeroEntry()
    #print(non_zero_values)
    print("Non Empty Value in DDT :", non_zero_values)
    #return non_zero_values

if __name__ == "__main__":
    main()
            
