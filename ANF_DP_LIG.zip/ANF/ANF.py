class Sbox:
    def __init__(self, sbox):
        self.sbox = sbox
        self.SBOXSIZE = self.SboxSize()

    def SboxSize(self):
        """    
        This function is used to calculate the size of a given sbox
        """
        s = format(len(self.sbox), "b")
        num_of_1_in_the_binary_expression_of_the_len_of_sbox = s.count("1")
        assert num_of_1_in_the_binary_expression_of_the_len_of_sbox == 1
        return (len(s) - 1)

    def BitProduct(self, u, x):
        """
        Return the value of the bitproduct function Pi_u(x)
        """
        if (u & x) == u:
            return 1
        else:
            return 0

    def GetTruthTable(self, u):
        """
        Retrieve the truth table of the boolean function Pi_u(y), where y = sbox(x)
        """
        temp = [u for i in range(len(self.sbox))]  #Create list [u u u u] if len(sbox)=4
        table = map(self.BitProduct, temp, self.sbox)
        # print("INSIDE GETTRUTHH: ", list(table))
        
        return list(table)

    def ProcessTable(self, table):
        """
        Process the truth table to get the ANF of the boolean function
        we use table size to calculate the SBOXSIZE
        """
        for i in range(0, self.SBOXSIZE):
            for j in range(0, 2**i):
                for k in range(0, 2**(self.SBOXSIZE - 1 - i)):
                    x = k + 2**(self.SBOXSIZE - 1 - i) + j*(2**(self.SBOXSIZE - i))
                    table[x] =\
                    table[k + 2**(self.SBOXSIZE - 1 - i) + j*(2**(self.SBOXSIZE - i))] ^\
                    table[k + j*(2**(self.SBOXSIZE - i))]

    def CreatANF(self):
        """
        Return the ANF of the sbox, moreover, this function also return the ANF of boolean function which
        is the product of some coordinates of the sbox output
        """
        ANF = [[]for i in range(0, len(self.sbox))]
        for i in range(1, len(self.sbox)):
            table = self.GetTruthTable(i)
            self.ProcessTable(table)
            sqr = []
            for j in range(0, len(self.sbox)):
                if list(table)[j] != 0: #Convert map object to list
                    sqr.append(j)
                    
            ANF[i] = sqr
            	
        return ANF


if __name__ == "__main__":

    cipher = "New_Inequalities"
    sbox = [0x6, 0x5, 0x0, 0x3, 0x1, 0x2, 0x7, 0x4]

    sb = Sbox(sbox)
    
    # Print size of SBOX in bits
    print(sb.SBOXSIZE)  # Accessing SBOXSIZE attribute, so need to use () for calling the method
  

    print("-----------------------------ANF_FORM OF SBOX------------------------------------------")
    print(sb.CreatANF())

